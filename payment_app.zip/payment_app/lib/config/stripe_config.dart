class StripeConfig {
  static const String publishableKey = 'pk_test_51TRTrkFdY6J6UCycNtVktdI0pyUdvbyGZ5rIFFILTE2sDaKgCwj9i19KkNzubaMIyW9hO2zDSpZewCTn8e0Csd2M00vFTNe548';
  static const String secretKey = 'sk_test_51TRTrkFdY6J6UCycRqQjYFPYsZTjs0zlHqto4cU7wssx4Qsi6hBr4KTG7IfdvXUQxSmuqijGRqPTnWwHBa7t8tqL00XSDzFpF2';

  static const String apiUrl = 'https://api.stripe.com/v1';

}